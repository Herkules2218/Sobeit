﻿#pragma once
// Shared menu / ESP settings. No inline font resource re-creation.
extern int g_OlympusNickFontIndex;  // 0..11
extern int g_OlympusNickOutline;    // 0..3 pixels
const char* OlympusNickFontLabel(int style);
void OlympusLoadNickSettings();
void OlympusSaveNickSettings();
