extern char AuthKeyTable[512 + 879][2][128];
