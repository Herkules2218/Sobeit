param([string]$Configuration = "Release")
$ErrorActionPreference = "Stop"
$project = Join-Path $PSScriptRoot "BlackLight\src\mod_sa_VS2015.vcxproj"
$vswhere = Join-Path ${env:ProgramFiles(x86)} "Microsoft Visual Studio\Installer\vswhere.exe"
if (-not (Test-Path $vswhere)) { throw "Visual Studio Build Tools / vswhere не знайдено" }
$msbuild = & $vswhere -latest -requires Microsoft.Component.MSBuild -find "MSBuild\**\Bin\MSBuild.exe" | Select-Object -First 1
if (-not $msbuild) { throw "MSBuild не знайдено. Встановіть VS 2022 з C++." }
Write-Host "Building Win32 release via: $msbuild"
& $msbuild $project /m /t:Rebuild "/p:Configuration=$Configuration" "/p:Platform=Win32" /v:minimal
if ($LASTEXITCODE -ne 0) { throw "Збірка неуспішна. Перевірте DirectX 9 (D3DX9), SDK і бібліотеки." }
Write-Host "Збірка завершена. Знайдіть створений d3d9.dll у теці збірки проєкту. Не замінюйте стабільну DLL без тесту!"
